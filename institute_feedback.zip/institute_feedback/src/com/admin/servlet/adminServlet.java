package com.admin.servlet;
import com.dao.crud.*;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class adminServlet
 */
@WebServlet("/adminServlet")
public class adminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public adminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String course = request.getParameter("course");
		String batch_no = request.getParameter("batch_no");
		String trainer_name = request.getParameter("trainer_name");
		Bean bn = new Bean();
		bn.setBatch_no(batch_no);
		bn.setCourse(course);
		bn.setTrainer_name(trainer_name);
		adminDao ad = new adminDao();
		ResultSet r = ad.crud(bn);
		try{
		while(r.next()){
			request.setAttribute("name", r.getString(1));
			request.setAttribute("course", r.getString(2));
			request.setAttribute("batch_no", r.getString(3));
			request.setAttribute("rating", r.getString(4));
			request.setAttribute("feed__back", r.getString(5));	
		}}catch(Exception e){}
		//System.out.println(course+" "+batch_no+" "+trainer_name);
		request.getRequestDispatcher("viewReviews.jsp").forward(request, response);
		//response.sendRedirect("viewReviews.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
