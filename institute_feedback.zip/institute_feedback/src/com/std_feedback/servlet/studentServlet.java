package com.std_feedback.servlet;
import com.dao.crud.*;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class studentServlet
 */
@WebServlet("/studentServlet")
public class studentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public studentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String course= request.getParameter("course");
	    String batch_no = request.getParameter("batch_no");
		String trainer_name = request.getParameter("trainer_name");
		String text = request.getParameter("text");
		String rating = request.getParameter("rating");
		Bean bn = new Bean();
		bn.setBatch_no(batch_no);
		bn.setCourse(course);
		bn.setRating(rating);
		bn.setTrainer_name(trainer_name);
		bn.setText(text);
		studentDao sd = new studentDao();
		sd.crud(bn);
		response.sendRedirect("thanks.jsp");
		//System.out.println(course+" "+batch_no+" "+" "+trainer_name+" "+text+" "+rating);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
