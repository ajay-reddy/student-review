package com.dao.crud;

import com.Db.connect.DbConnect;
import java.sql.*;
public class studentDao {
	String user,pass;
    public int crud(Bean bn)
    {
    	int exist = 0;
    	String trainer_name= bn.getTrainer_name();
    	String course= bn.getCourse();
    	String text= bn.getText();
    	String batch_no= bn.getBatch_no();
    	String rating= bn.getRating();
    	DbConnect db = new DbConnect();
    	int n = Integer.valueOf(batch_no);
		Statement stmt = null;
		Connection con = null;
		con = db.checkConnection();
		if(db.checkConnection()!=null)
		{
			try{
			stmt = con.createStatement();
			String sql = "insert into feedback (name,course,batch_no,feed__back,rating) values (?,?,?,?,?)";
			//String sql1 = "select username,password from student_info where username=? and password=?";
			//String sql = "insert into student_info (id,student_name,username,password,course,batch_no) values (?,?,?,?,?,?)";
			PreparedStatement prepstmt = con.prepareStatement(sql);
			prepstmt.setString(1,trainer_name);
			prepstmt.setString(3,batch_no);
			prepstmt.setString(2,course);
			prepstmt.setString(4,text);
			prepstmt.setString(5,rating);
			int n1 = prepstmt.executeUpdate();
			}
			
			catch(Exception e){}
		}
		else
			System.out.println("not success");
		return exist;
	}

    }
