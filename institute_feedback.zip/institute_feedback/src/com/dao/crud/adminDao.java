package com.dao.crud;

import com.Db.connect.DbConnect;
import java.sql.*;
public class adminDao {
	String rating,feedback;
    public ResultSet crud(Bean bn)
    {
    	int exist = 0;
    	String course= bn.getCourse();
    	String batch_no= bn.getBatch_no();
    	String trainer_name = bn.getTrainer_name();
    	DbConnect db = new DbConnect();
		Statement stmt = null;
		Connection con = null;
		con = db.checkConnection();
		ResultSet rs=null;
		if(db.checkConnection()!=null)
		{
			try{
			stmt = con.createStatement();
			String sql1 = "select name,course,batch_no,rating,feed__back from feedback where name=? and course=? and batch_no=? ";
			
			PreparedStatement prepstmt = con.prepareStatement(sql1);
			prepstmt.setString(1,trainer_name);
			prepstmt.setString(2,course);
			prepstmt.setString(3,batch_no);
			 rs = prepstmt.executeQuery();
			/*while(rs.next())
			{
				trainer_name = rs.getString("name");
				course = rs.getString("course");
				batch_no = rs.getString("batch_no");
				rating = rs.getString("rating");
				feedback = rs.getString("feed_back");
				//System.out.println(trainer_name+" "+course+" "+batch_no+" "+rating+" "+feedback);
				//System.out.println();
				//request.getReques
			}*/
			
			if(trainer_name.equals(null))
			{
				exist = 0;
				System.out.println("no such feedback");
			}
			else
				exist = 1;
			}
			
			catch(Exception e){}
		}
		else
			System.out.println("not success");
		return rs;
	}

    }
