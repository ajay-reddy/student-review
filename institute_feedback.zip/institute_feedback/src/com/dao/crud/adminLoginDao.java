package com.dao.crud;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.Db.connect.DbConnect;

public class adminLoginDao {

	String user,pass;
    public int crud(Bean bn)
    {
    	int exist = 0;
    	String username= bn.getUsername();
    	String password= bn.getPassword();
    	DbConnect db = new DbConnect();
		Statement stmt = null;
		Connection con = null;
		con = db.checkConnection();
		if(db.checkConnection()!=null)
		{
			try{
			stmt = con.createStatement();
			String sql1 = "select username,password from admin_info where username=? and password=?";
			//String sql = "insert into student_info (id,student_name,username,password,course,batch_no) values (?,?,?,?,?,?)";
			PreparedStatement prepstmt = con.prepareStatement(sql1);
			prepstmt.setString(1,username);
			prepstmt.setString(2,password);
			ResultSet rs = prepstmt.executeQuery();
			while(rs.next())
			{
				user = rs.getString("username");
				pass = rs.getString("password");
			}
			System.out.println(user+" "+pass);
			if(user.equals(null))
				exist = 0;
			else
				exist = 1;
			}
			
			catch(Exception e){}
		}
		else
			System.out.println("not success");
		return exist;
	}


	}


