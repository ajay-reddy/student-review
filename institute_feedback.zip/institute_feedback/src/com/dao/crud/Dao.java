package com.dao.crud;
import com.Db.connect.DbConnect;
import java.sql.*;
public class Dao {
    public void crud(Bean bn)
    {
    	String name= bn.getName();
    	String username= bn.getUsername();
    	String password= bn.getPassword();
    	String course= bn.getCourse();
    	String batch_no= bn.getBatch_no();
    	String sid= bn.getSid();
    	DbConnect db = new DbConnect();
		Statement stmt = null;
		Connection con = null;
		con = db.checkConnection();
		
		if(db.checkConnection()!=null)
		{
			try{
			stmt = con.createStatement();
			String sql = "insert into student_info (id,student_name,username,password,course,batch_no) values (?,?,?,?,?,?)";
			PreparedStatement prepstmt = con.prepareStatement(sql);
			prepstmt.setString(1,sid);
			prepstmt.setString(2,name);
			prepstmt.setString(3,username);
			prepstmt.setString(4,password);
			prepstmt.setString(5,course);
			prepstmt.setString(6,batch_no);
			int n = prepstmt.executeUpdate();
			}
			catch(Exception e){}
		}
		else
			System.out.println("not success");
	}

    }
	
