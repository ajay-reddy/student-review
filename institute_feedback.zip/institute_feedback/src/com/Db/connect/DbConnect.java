package com.Db.connect;
import java.sql.*;
public class DbConnect {
    public Connection checkConnection()
    {
    	Connection con = null;
    	try{
    	try{
    		Class.forName("com.mysql.cj.jdbc.Driver");  
		  
    	}catch(Exception e){ 
    		System.out.println(e);
    		} 
    	 con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3307/feedback_db","root","alaalaala7");
    	 //java.sql.Statement stmt=con.createStatement();
    	// ResultSet rs = stmt.executeQuery("SELECT * FROM admin_table");
    	 
    	}catch(Exception e){
    		System.out.println(e);
    	}
    	return con;
    }
	/*public static void main(String[] args) {
		// TODO Auto-generated method stub
		DbConnect db = new DbConnect();
		System.out.println(db.checkConnection());
	}*/

}
