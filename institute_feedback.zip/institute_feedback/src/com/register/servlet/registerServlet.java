package com.register.servlet;
import com.dao.crud.*;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class registerServlet
 */
@WebServlet("/registerServlet")
public class registerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public registerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    Bean bn = new Bean();
	    Dao da = new Dao();
		String name = request.getParameter("name");
		String username = request.getParameter("username");
		String password = request.getParameter("pass");
		String course = request.getParameter("course");
		String batch_no = request.getParameter("batch_no");
		String sid = request.getParameter("sid");
		//System.out.println(name+" "+username+" "+password+" "+course+" "+batch_no+" "+sid);
		bn.setName(name);
		bn.setUsername(username);
		bn.setPassword(password);
		bn.setCourse(course);
		bn.setBatch_no(batch_no);
		bn.setSid(sid);
		response.sendRedirect("login.jsp");
		da.crud(bn);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
